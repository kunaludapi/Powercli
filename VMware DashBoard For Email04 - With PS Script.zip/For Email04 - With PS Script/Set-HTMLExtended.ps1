#function Set-HTMLExtended {
    [CmdletBinding(SupportsShouldProcess=$true)]
    param
    (
        [string]$HtmlFilePath = 'C:\Temp\test.htm'
    )
    begin 
    {
        $vCenterSummary = Import-Csv -Path .\csv\vCenterSummary.csv
        $esxiSummary = Import-Csv -Path .\csv\EsxiSummary.csv
        $racSummary = Import-Csv -Path .\csv\RACSummary.csv
        $healthSummary = Import-Csv -Path .\csv\HealthSummary.csv
        $vCenterFailedStatus = Import-Csv -Path .\csv\vCenterFailedStatus.csv
        $EsxiFailedStatus = Import-Csv -Path .\csv\EsxiFailedStatus.csv
        $htmlPart01 = Get-Content -Path .\parts\htmlPart01.txt
        $htmlPart02 = Get-Content -Path .\parts\htmlPart02.txt

        function Set-TableData
        {
            param
            (
                [PSObject]$TableData
            )

            $HeaderNames = $TableData[0].psObject.Properties.Name

            foreach ($data in $TableData) {
                "<tr>"
                for ($i=0; $i -le ($HeaderNames.Count - 1); $i++) 
                {
                    "<td>{0}</td>" -f $data.$($HeaderNames[$i])
                }
                "</tr>"
            }
        } #function Set-TableData   

    }
    process
    {
        $htmlPart03 = @"
<!--vCenter DashBoard-->                
                <div id="vCenter">
                    <div id="vCenterDashboard">
                        <div id="vCenterDashboard01">
                            <h2>$($vCenterSummary.TotalvCenterCount)</h2>
                            <h4>Total vCenter Count</h4>
                        </div>
                        <div id="vCenterDashboard02">
                            <h2>$($vCenterSummary.OKvCenter)</h2>
                            <h4>OK vCenter</h4>
                        </div>
                        <div id="vCenterDashboard03">
                            <h2>$($vCenterSummary.NotOkvCenter)</h2>
                            <h4>NotOK vCenter</h4>
                        </div>
                    </div>
                </div>

<!--vCenter DashBoard Header-->                       
                <div id="inventorySummary">
                    <h3>VCENTER SUMMARY</h3>
                </div>                                
"@

        $htmlPart04 = @"
<!--ESXi DashBoard-->
                <div id="ESXi">
                    <div id="esxiDashboard">
                        <div id="esxiDashboard01">
                            <h2>$($esxiSummary.TotalEsxiCount)</h2>
                            <h5>Total ESXi Count</h5>
                        </div>
                        <div id="esxiDashboard02">
                            <h2>$($esxiSummary.MaintenanceMode)</h2>
                            <h5>Maintenance Mode</h5>
                        </div>
                        <div id="esxiDashboard03">
                            <h2>$($esxiSummary.NotRespondingInVC)</h2>
                            <h5>Non responding in VC</h5>
                        </div>
                        <div id="esxiDashboard04">
                            <h2>$($esxiSummary.EsxiNotPingable)</h2>
                            <h5>Esxi Not Pinging</h5>
                        </div>
                        <div id="esxiDashboard05">
                            <h2>$($esxiSummary.Unknown)</h2>
                            <h5>Esxi unknown status</h5>
                        </div>
                    </div>
                </div>

<!--Esxi DashBoard Header-->                       
                <div id="inventorySummary">
                    <h3>ESXi SUMMARY</h3>
                </div>
"@

        $htmlPart05 = @"
<!--Remote Console DashBoard-->
                <div id="iloRack">
                    <div id="racDashboard">
                        <div id="racDashboard01">
                            <h2>$($racSummary.RacPingable)</h2>
                            <h4>RAC Pingable</h4>
                        </div>
                        <div id="racDashboard02">
                            <h2>$($racSummary.RacNonPingable)</h2>
                            <h4>RAC Non pingable</h4>
                        </div>
                        <div id="racDashboard03">
                            <h2>$($racSummary.RACNoDNS)</h2>
                            <h4>RAC No DNS</h4>
                        </div>
                        <div id="racDashboard04">
                            <h2>$($racSummary.IBMBlades)</h2>
                            <h4>IBM Blades</h4>
                        </div>
                    </div>

<!--Remote Console Header-->
                    <div id="inventorySummary">
                        <h3>Remote Console (ILO | iDRAC | IMM )</h3>
                    </div>                   
                </div>    
"@

        $htmlPart06 = @"
<!--Health Summary-->
                <div id="healthSummary">
                    <div id="offGrid">
                        <h4>vCenter Status Not Ok: $($vCenterSummary.NotOkvCenter)</h4>
                    </div>
                    <div id="onGrid">
                        <h4>Esxi in Maintenance Mode: $($esxiSummary.MaintenanceMode)</h4>
                    </div>
                    <div id="offGrid">
                        <h4>ESXi or RAC not pingable: $($healthSummary.EsxiILONotPinging)</h4>
                    </div>
                    <div id="onGrid">
                        <h4>Unconfigured ILO: $($healthSummary.UnconfiguredILO)</h4>
                    </div>
                    <div id="offGrid">
                        <h4>ESXi with alarm disabled: $($healthSummary.EsxiAlarmDisabled)</h4>
                    </div>
                    <div id="onGrid">
                        <h4>ESXi with NTP issues: $($healthSummary.EsxiNTPIssues)</h4>
                    </div>
                    <div id="offGrid">
                        <h4>ESXi with dead storage path: $($healthSummary.EsxiWithDeadStoragePaths)</h4>
                    </div>
                </div> <!-- <div id="healthSummary"> -->        
"@

        $htmlPart07 = @"
<!--Health Summary Charts-->
<!-- (Line Charts1)"> -->
                <div id="allhealthSummaryCharts"> 
                    <canvas id="myChart" width="auto" height="300"></canvas>
                    <script>
                        let myChart = document.getElementById('myChart').getContext('2d');
                        Chart.defaults.global.defaultFontSize = 12;
                        Chart.defaults.global.defaultFontColor = '#777';
                        let massPopChart = new Chart(myChart, {
                            type:'bar', 
                            data:{
                            labels:['VC Not OK', 'Maintenance Mode', 'ESXi-ILO no ping', 'ILO unconfigured', 'Alarm Disabled', 'NTP issues', 'Dead Storage Path'],
                            datasets:[{
                                label: "Count" ,
                                data:[$($vCenterSummary.NotOkvCenter), $($esxiSummary.MaintenanceMode), $($healthSummary.EsxiILONotPinging), $($healthSummary.UnconfiguredILO), $($healthSummary.EsxiAlarmDisabled), $($healthSummary.EsxiNTPIssues), $($healthSummary.EsxiWithDeadStoragePaths)],
                                backgroundColor:'rgba(0,191,255, 0.6)',
                                hoverBackgroundColor: 'rgba(255,165,0, 0.6)',
                                borderWidth:1,
                                borderColor:'#777',
                                hoverBorderWidth:3,
                                hoverBorderColor:'#000',
                                fontsize:10,
                            }]
                            },
                            options:{
                            title:{
                                display:false,
                                fontSize:8
                            },
                            legend:{
                                display:false,
                                position:'bottom',
                                labels:{
                                fontColor:'Gray',
                                fontSize:12,
                                }
                            },
                            layout:{
                                padding:{
                                left:0,
                                right:0,
                                bottom:0,
                                top:0
                                }
                            },
                            tooltips:{
                                enabled:true,
                                titleFontSize:10
                            },
                            
                            scales: {
                                yAxes: [{
                                    ticks: {
                                        beginAtZero: false,
                                        display: true, //label show\hide
                                        fontSize:10,
                                    },
                                    gridLines: {
                                        display:true,
                                        drawBorder: true,
                                    }
                                }],
                                xAxes: [{
                                    // Change here
                                    barPercentage: 1,
                                    ticks:{
                                        fontSize: 12, 
                                        display: true, //label show\hide
                                    },
                                    gridLines: {
                                        //color: "rgba(0, 0, 0, 0)",
                                        //lineWidth: 0
                                        display:true, 
                                        drawBorder: true,
                                    }
                                }]
                            }		
                            }
                        });
                    </script>
                </div> <!-- <div id="healthSummaryCharts (Line Charts)"> -->

<!-- (Doughnut Charts1)"> -->
                <div id="allhealthSummaryCharts"> 
                    <canvas id="myChartDoughnut01" Width="500" Height="250"></canvas>
                    <script>
                        var data = {
                        labels: ['Maintenance mode', 'Not Responding in VC', 'Esxi Not Pinging', 'Unknown Status'],
                        datasets: [{
                            label: "Status",
                            backgroundColor: [
                                "rgba(0,191,255,0.6)", 
                                "rgba(255,64,0,0.6)",
                            ],
                            hoverBackgroundColor: [
                                "rgba(0,191,255, 1)", 
                                "rgba(255, 64, 0, 1)",
                            ],
                            pointHoverRadius: 5,
                            strokeColor: "#f26b5f",
                            pointColor: "#f26b5f",		
                            //borderColor: "rgba(75,192,192,1)",
                            data: [$($esxiSummary.MaintenanceMode), $($esxiSummary.NotRespondingInVC), $($esxiSummary.EsxiNotPingable), $($esxiSummary.Unknown)],
                            hoverBorderWidth:3,
                            hoverBorderColor:'#000',
                            showLine: false
                        }]
                    };
                    var ctx = document.getElementById("myChartDoughnut01");
                    var myChartDoughnut01 = new Chart(ctx, {
                        type: 'doughnut',
                        data: data,
                        responsive: true,
                        options: {
                            legend: {
                                display: false
                            },
                            tooltips: {
                                enabled: true,
                                mode: 'single'
                            },
                            scales: {
                                yAxes: [{
                                    ticks: {
                                        display: false,
                                        fontColor: 'white',
                                    },
                                    gridLines: {
                                        display:false,
                                        drawBorder: false,
                                    }
                                }],
                                xAxes: [{
                                    // Change here
                                    barPercentage: 1,
                                    ticks:{
                                        fontColor: 'white',
                                    },
                                    gridLines: {
                                        display:false,
                                        drawBorder: false,
                                    }
                                }]
                            }
                        }
                    });
                    </script>
                </div> <!-- <div id="healthSummaryCharts (Doughnut Charts1)"> -->
        
"@

        $htmlPart08 = @"
            <!--vCenter table-->
                <div id="tableHeader">
                    <h3>VCENTER TABLE</h3>
                </div>  

                <div id="Table01">
                    <div class="table-responsive">
                        <table id="myTable" class="display table" width="100%">
                            <thead>
                                <tr>
                                <th>vCenter Server</th>
                                <th>Location</th>
                                <th>Clusters</th>
                                <th>Esxi</th>
                                <th>VMs</th>
                                </tr>  
                            </thead>  
                            <tbody>
"@

        $htmlPart09 = Set-TableData -TableData $vCenterFailedStatus
        
        $htmlPart10 = @'
                            </tbody>  
                        </table>
                    </div>

                    <script>
                        $(document).ready(function(){
                            $('#myTable').dataTable();
                        });
                    </script>
                </div>

<!--Esxi in Maintenance Mode table-->
                <div id="tableHeader">
                    <h3>Esxi in Maintenance Mode</h3>
                </div>

                <div id="Table01">
                    <div class="table-responsive">
                        <table id="myTable02" class="display table" width="100%">
                            <thead>  
                                <tr>
                                <th>vCenter Server</th>
                                <th>Cluster</th>
                                <th>Hosts</th>
                                <th>Connection State</th>
                                <th>Maintenance Mode</th>
                                <th>Open Inc</th>
                                </tr>  
                            </thead>  
                            <tbody>          
'@
        
        $htmlPart11 = Set-TableData -TableData $EsxiFailedStatus

        $htmlPart12 = @'
                            </tbody>  
                        </table>
                    </div>

                    <script>
                        $(document).ready(function(){
                            $('#myTable02').dataTable();
                        });
                    </script>
                </div>

<!--Footer-->
                <div id="footer">
                    Drop an email to Kunal for modification.
                </div>
                
<!--Content End -->
            </div>

<!--Container End -->
        </div>

    </body>
</html>
'@
    }

    end 
    {
        $completeHTMLPage = $htmlPart01 + $htmlPart02 + $htmlPart03 + $htmlPart04 + $htmlPart05 + $htmlPart06 + $htmlPart07 + $htmlPart08 + $htmlPart09 + $htmlPart10 + $htmlPart11 + $htmlPart12
        $completeHTMLPage | Out-File -FilePath $HtmlFilePath
        Invoke-Expression $HtmlFilePath
    }
#}