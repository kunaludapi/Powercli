var vcenterjsondata = '{"vctotalcount":302,"location390":172,"FDC":22,"GTDC":30,"HK":22,"JPN":18,"JRDC":56,"KOR":46,"MWDC":8,"QRDC":98,"RDC":35,"RUTH":15,"SG":54,"SG3":40,"SWDC":35,"Techroom":65}';
var vcentercontinents = '{"apac":34,"apackor":39,"emea":52,"latam":20,"nam":11,"stinam":52}';
var racjsondata = '{"racpingable":2443,"racnonpingable":254,"racnodns":125,"ibmblades":434}';
var healthsummaryjsondata = '{"notokvcenter":22,"maintenancemode":145,"esxilonoping":125,"unconfiguredilo":98,"alarmdisabled":49,"ntpissues":20,"deadstoragepath":27}';

//For charts if you don't want to use quotes only use below var names as for data "Object.values(barchartjsondata)" and for member properties "Object.keys(barchartjsondata)" 
var continentsbarchartjson01 = '{"apac":34,"apackor":39,"emea":52,"latam":20,"nam":11,"stinam":52}';
var datacenterbarchartjson01 = '{"location390":172,"FDC":22,"GTDC":30,"HK":22,"JPN":18,"JRDC":56,"KOR":46,"MWDC":8,"QRDC":98,"RDC":35,"RUTH":15,"SG":54,"SG3":40,"SWDC":35,"Techroom":65}';
var doughnutchartjsondata01 = '{"okvcenter":173,"notokvcenter":20,"noshowhostingvms":19}';