var vcentersummarydata = JSON.parse(vcenterjsondata);
var vcentercontinentdata = JSON.parse(vcentercontinents);
var racsummarydata = JSON.parse(racjsondata);
var healthsummarydata = JSON.parse(healthsummaryjsondata);

//Charts not required but keeping but I will be using same data in left side array queue row.
var continentsbarchartdata01 = JSON.parse(continentsbarchartjson01);
var datacenterbarchartdata01 = JSON.parse(datacenterbarchartjson01);
var doughnutchartdata01 = JSON.parse(doughnutchartjsondata01);
//alert(data.foo);