#!/usr/bin/env python
#!/bin/python
import json
with open('/tmp/info.json') as file:
    data_json = json.load(file)
for results in data_json['results']:
    data = []
    hostname = results['item']['name']
    a = "UserVars.ESXiShellTimeOut" + ": " + str(results['hosts_info'][hostname]['UserVars.ESXiShellTimeOut'])
    b = "NFS.MaxVolumes" + ": " + str(results['hosts_info'][hostname]['NFS.MaxVolumes'])
    c = "NFS.HeartbeatFrequency" + ": " + str(results['hosts_info'][hostname]['NFS.HeartbeatFrequency'])
    d = "NFS.HeartbeatTimeout" + ": " + str(results['hosts_info'][hostname]['NFS.HeartbeatTimeout'])
    e = "Net.TcpipHeapSize" + ": " + str(results['hosts_info'][hostname]['Net.TcpipHeapSize'])
    data.extend({hostname})
    data.extend({a, b, c, d, e})
    print(data)

#UserVars.ESXiShellTimeOut 1800
#NFS.MaxVolumes 256
#NFS.HeartbeatFrequency 12
#NFS.HeartbeatMaxFailures 10
#NFS.HeartbeatTimeout 5
#Net.TcpipHeapSize 32
